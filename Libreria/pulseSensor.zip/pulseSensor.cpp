#include "pulseSensor.h"
#include "Arduino.h"

pulseSensor::pulseSensor(int analogPin)
{
    pinMode(analogPin, INPUT);
    _analogPin = analogPin;
}

void pulseSensor::buzzerActivation(int s, int threshold, int buzzerPin)
{
	if (s >= threshold)
	{
		digitalWrite(buzzerPin, HIGH);
	}
	if (s < threshold)
	{
		digitalWrite(buzzerPin, LOW);
	}
}

void pulseSensor::getBPMValue(int s)
{	
	static unsigned long tiempoLPM = millis();
	static unsigned long entreLatidos = millis();
	
	float valorFiltrado = _factor * _valorAnterior + (1 - _factor) * s;
	float cambio = valorFiltrado - _valorAnterior;
	_valorAnterior = valorFiltrado;
	
	if ((cambio >= _maximo) && (millis() > entreLatidos + _minimoEntreLatidos))
	{
		_maximo = cambio;
		entreLatidos = millis();
		_latidos++;  
	}
	
	_maximo = _maximo * 0.97;
	
	if (millis() >= tiempoLPM + 15000)
	{
		_latidos = _latidos * 4;
		Serial.println(_latidos + 20);
		_latidos = 0;
		tiempoLPM = millis();  
	}
}