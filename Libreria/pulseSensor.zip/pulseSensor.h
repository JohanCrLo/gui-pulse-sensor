#ifndef pulseSensor_h
#define pulseSensor_h
#include "Arduino.h"

class pulseSensor
{
    public:
        pulseSensor(int analogPin);
        void buzzerActivation(int s, int threshold, int buzzerPin);
		void getBPMValue(int s);
	 private:
        int _analogPin;
		float _factor = 0.75;
		float _maximo = 0.0;
		int _minimoEntreLatidos = 300;
		float _valorAnterior = 500;
		int _latidos = 6;
};

#endif